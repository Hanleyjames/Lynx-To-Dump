document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("requestButton").addEventListener("click", sendRequest);
});
function sendRequest(){
			let result = document.querySelector('.result');
			let newsurl = document.querySelector('#newsurl');
			let email = document.querySelector('#email');
      let form = document.querySelector('.form');
      form.innerHTML = "Uploading";
      let xhr = new XMLHttpRequest();
			let url = "https://blazeit420.herokuapp.com/lynxdumps";
			xhr.open("POST", url, true);
			xhr.setRequestHeader("Content-Type", "application/json");
			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4 && xhr.status === 200) {
          form.innerHTML = "";
					result.innerHTML = "Message Sent, please close the extension";
				} else if (xhr.readyState === 4 && xhr.status !== 200) {
          form.innerHTML = "";
          result.innerHTML = "Server Error, please close the extension and try again";
        }
			};
			var data = JSON.stringify({ "newsurl": newsurl.value, "email": email.value });
			xhr.send(data);
};
